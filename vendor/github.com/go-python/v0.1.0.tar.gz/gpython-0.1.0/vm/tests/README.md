Tests for VM
============

These simple programs are designed to exercise the VM.

They should run with no errors raised.

They should also all run clean with python3.4

Set doc="string" before every test

Set doc="finished" at the end

If you want to test an error is raised properly, then set
err=ErrorObject so the test runner can check the error was raised
properly.
