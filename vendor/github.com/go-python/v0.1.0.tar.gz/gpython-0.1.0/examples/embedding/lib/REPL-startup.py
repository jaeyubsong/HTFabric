# Copyright 2022 The go-python Authors.  All rights reserved.
# Use of this source code is governed by a BSD-style
# license that can be found in the LICENSE file.

# This file is called from main.go when in REPL mode		

# This is here to demonstrate making life easier for your users in REPL mode
# by doing pre-setup here so they don't have to import every time they start.
from mylib import *

